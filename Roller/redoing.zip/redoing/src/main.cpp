// #include <AccelStepper.h>

#include <StepperMotor.h>
// Pin definitions

// lane 4
#define DIR_PIN 11
#define STEP_PIN 12
#define SWITCH_PIN 38

// lane 3
// #define DIR_PIN 15
// #define STEP_PIN 16
// #define SWITCH_PIN 36

// lane 2
// #define DIR_PIN 13
// #define STEP_PIN 14
// #define SWITCH_PIN 32

// lane 1
// #define DIR_PIN 17
// #define STEP_PIN 18
// #define SWITCH_PIN 30

// #define LED_IDLE_PIN 3
// #define LED_MOVING_TO_HOME_PIN 4
// #define LED_BACKING_OFF_SWITCH_PIN 5

#define MOTOR_INTERFACE_TYPE 1

StepperMotor motor(MOTOR_INTERFACE_TYPE, STEP_PIN, DIR_PIN, SWITCH_PIN);

void setup() {
  delay(250);
  Serial.begin(115200);
  // motor.moveToHome();
}

void loop() {

  motor.update();
  // Add the serial controls back
  if (Serial.available()) {
    String command = Serial.readStringUntil('\n');
    Serial.println(command);


    if (command.startsWith("m"))
    {
      int steps = command.substring(1).toInt();
      Serial.print("-- steps: ");
      Serial.println(steps);
      motor.moveToPosition(steps);
      // motor.move(steps);
    } else if (command.startsWith("s")) {
      int speed = command.substring(1).toInt();
      Serial.print("-- speed: ");
      Serial.println(speed);
      motor.setSpeed(speed);
    } else if (command.startsWith("x")) {
      Serial.println("--stop");
      motor.stop();
    } else if (command.startsWith("h")) {
      Serial.println("--home");
      motor.moveToHome();
    } else {
      Serial.print("err: ");
      Serial.println(command);
    }
  }
  
}