/*
#include <AccelStepper.h>

#define DIR_PIN 11
#define STEP_PIN 12
#define SWITCH_PIN 38
#define LED_IDLE_PIN 3
#define LED_MOVING_TO_HOME_PIN 4
#define LED_BACKING_OFF_SWITCH_PIN 5

#define MOTOR_INTERFACE_TYPE 1

enum MotorState {
IDLE,
MOVING_TO_HOME,
BACKING_OFF_SWITCH,
REVERSING,
STOPPED
};

class StepperMotor {
private:
AccelStepper stepper;
int homeSwitchPin;
int ledIdlePin;
int ledMovingToHomePin;
int ledBackingOffSwitchPin;
MotorState state;
bool previousSwitchState;
bool homed;

public:
StepperMotor(int interface, int step, int dir, int homeSwitch, int ledIdle, int ledMovingToHome, int ledBackingOffSwitch)
: stepper(interface, step, dir),
homeSwitchPin(homeSwitch),
ledIdlePin(ledIdle),
ledMovingToHomePin(ledMovingToHome),
ledBackingOffSwitchPin(ledBackingOffSwitch),
state(IDLE),
previousSwitchState(true),
homed(false) {
pinMode(homeSwitchPin, INPUT_PULLUP);
pinMode(ledIdlePin, OUTPUT);
pinMode(ledMovingToHomePin, OUTPUT);
pinMode(ledBackingOffSwitchPin, OUTPUT);
stepper.setMaxSpeed(2000.0);
stepper.setAcceleration(1000.0);
stepper.setSpeed(1000.0);
}

void moveToHome() {
if (!homed) {
state = MOVING_TO_HOME;
digitalWrite(ledIdlePin, LOW);
digitalWrite(ledMovingToHomePin, HIGH);
digitalWrite(ledBackingOffSwitchPin, LOW);
stepper.moveTo(40000);
}
}

void update() {
bool currentSwitchState = digitalRead(homeSwitchPin);

if (state == MOVING_TO_HOME) {
if (!previousSwitchState && currentSwitchState) {
state = BACKING_OFF_SWITCH;
stepper.stop();
stepper.setCurrentPosition(0);
}
} else if (state == BACKING_OFF_SWITCH) {
if (previousSwitchState && !currentSwitchState) {
state = REVERSING;
stepper.setSpeed(-500);
stepper.moveTo(-200);
}
} else if (state == REVERSING) {
if (!stepper.isRunning()) {
state = STOPPED;
stepper.setCurrentPosition(0);
}
} else if (state == STOPPED || state == IDLE) {
if (!previousSwitchState && currentSwitchState) {
state = MOVING_TO_HOME;
stepper.setSpeed(1000);
stepper.moveTo(40000);
}
}

digitalWrite(ledIdlePin, state == STOPPED || state == IDLE);
digitalWrite(ledMovingToHomePin, state == MOVING_TO_HOME);
digitalWrite(ledBackingOffSwitchPin, state == BACKING_OFF_SWITCH || state == REVERSING);

previousSwitchState = currentSwitchState;
stepper.run();

if (state == STOPPED) {
homed = true;
}
}

bool getHasHomed() {
return homed; // Function to return the homed state
}

void move(int steps) { // Function to move a certain number of steps
if (state == IDLE) {
stepper.move(steps);
}
}

void setSpeed(int speed) { // Function to set the speed
if (state == IDLE) {
stepper.setSpeed(speed);
}
}

void stop() { // Function to stop the stepper
if (state != MOVING_TO_HOME && state != BACKING_OFF_SWITCH) {
stepper.stop();
}
}
};

StepperMotor motor(MOTOR_INTERFACE_TYPE, STEP_PIN, DIR_PIN, SWITCH_PIN, LED_IDLE_PIN, LED_MOVING_TO_HOME_PIN, LED_BACKING_OFF_SWITCH_PIN);

void setup() {
Serial.begin(9600);
motor.moveToHome();
}

void loop() {
motor.update();

// Add the serial controls back
if (Serial.available()) {
String command = Serial.readStringUntil('\n');

if (command.startsWith("move")) {
int steps = command.substring(5).toInt();
motor.move(steps);
} else if (command.startsWith("speed")) {
int speed = command.substring(6).toInt();
motor.setSpeed(speed);
} else if (command.startsWith("stop")) {
motor.stop();
}
}
}
*/