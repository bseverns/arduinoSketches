# ifndef STEPPERMOTOR_H
# define STEPPERMOTOR_H

#include "Arduino.h"
#include <AccelStepper.h>

enum MotorState {
  INIT,
  MOVING_TO_HOME,
  MOVING_TO_SOFTHOME,
  BACKING_OFF_SWITCH,
  AT_SOFT_HOME,
  AT_END,
  MOVING_TO_POSITION,
  STOPPED
};

class StepperMotor {
  private:
    AccelStepper stepper;
    int homeSwitchPin;
    MotorState state;
    bool previousSwitchState;
    long cpos = 0;

  public:
    StepperMotor(int interface, int step, int dir, int homeSwitch)
      : stepper(interface, step, dir),
        homeSwitchPin(homeSwitch),
        state(INIT),
        previousSwitchState(true) {
      pinMode(homeSwitchPin, INPUT_PULLUP);
      stepper.setMaxSpeed(250);      // Adjust the maximum speed (steps per second)
      stepper.setAcceleration(500000);  // Adjust the acceleration (steps per second per second)
      stepper.setSpeed(250);         // Set the initial speed
      stepper.setCurrentPosition(0);    // Set the current position as START_ZERO
  }

    void moveToHome();

    void reset();

    void moveToPosition(long position);

    void stop();

    void update();

    void move(int steps);

    // long position();

    MotorState getState();

    void setSpeed(int speed);

};

# endif // STEPPERMOTOR_H