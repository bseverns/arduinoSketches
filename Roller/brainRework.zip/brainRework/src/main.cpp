//Roller Racer - Motor Controller Brain
//Target Winter Street Studio
//June 2023
//B.Severns

//libraries
#include <SD.h>
#include <SPI.h>
#include <Arduino.h>
#include <elapsedMillis.h>

// Custom Libraries
#include <gameDefs.h>
#include <stepperFuncs.h>
// #include <rollerRacer.h>

void runTillStopped(){
  while(
    stepper[0].getState() != STOPPED ||
    stepper[1].getState() != STOPPED ||
    stepper[2].getState() != STOPPED ||
    stepper[3].getState() != STOPPED
    ){
      for (int i = 0; i < N_STEPPERS; i++)
      {
        stepper[i].update();
      }
    }
}

void setup()
{


  strip.begin(); //start the neopixel
  strip.show();

  Serial.begin(115200); // Serial monitor
  Serial.println("Setup initialized");
  Serial1.begin(115200); // Serial1 for lane 1
  Serial6.begin(9600); // Serial6 for lane 2
  Serial7.begin(9600); // Serial7 for lane 3
  Serial8.begin(9600); // Serial8 for lane 4

  // while(!Serial){delay(1);} // wait for serial debug connection

  for (int i = 0; i < N_STEPPERS; i++) //setup the motors/home sensors
  {
    stepper[i].moveToHome();
  }

  runTillStopped();

  // AudioMemory(12);
  pinMode(startButton, INPUT_PULLUP);
  // Attach an interrupt to digital pin 2, on falling edge (from HIGH to LOW)
  // attachInterrupt(digitalPinToInterrupt(startButton), buttonPress, RISING);
  for (int i = 0; i < LANE_COUNT; ++i)
  {
    pinMode(DEBUG_LED[i], OUTPUT);
    digitalWrite(DEBUG_LED[i], LOW);
    delay(5);
    digitalWrite(DEBUG_LED[i], HIGH);
    delay(50);
    digitalWrite(DEBUG_LED[i], LOW);
  }

  // Attach interrupts for each home sensor
  // attachInterrupt(digitalPinToInterrupt(HOME_SENSOR(0)), handleHomeSensorInterrupt0, CHANGE);
  // attachInterrupt(digitalPinToInterrupt(HOME_SENSOR(1)), handleHomeSensorInterrupt1, CHANGE);
  // attachInterrupt(digitalPinToInterrupt(HOME_SENSOR(2)), handleHomeSensorInterrupt2, CHANGE);
  // attachInterrupt(digitalPinToInterrupt(HOME_SENSOR(3)), handleHomeSensorInterrupt3, CHANGE);

  currentState = WaitingToStart; // Set the initial state

  // Print the initial state
  /*
  switch (currentState)
  {
    case Initialising:
      Serial.println("Initialising state");
      homeAllSteppers();
    break;

    case WaitingToStart:
      Serial.println("WaitingToStart state");
    break;

    case Playing:
      Serial.println("Playing state");
    break;

    case GameOver:
      Serial.println("GameOver state");
    break;

    case Resetting:
      Serial.println("Resetting state");
    break;

    // NOTE: missing default
    default:
    break;
  }
  */
}

uint32_t cmils = millis();
uint32_t pmils = cmils;
int i = 0;
long pos = 0;

void loop() {
  cmils = millis();
  // Read the button state
  int reading = digitalRead(startButton);
  // Serial.println(reading);


  // Check for a button press with debouncing
  if (reading != lastButtonState)
  {
    buttonPressTime = millis(); // record the time of the button press
  }

  if (reading == LOW && millis() - buttonPressTime > debounceDelay)
    {
    // Check if the game has started
    if (!isGameStarted )
    {
      Serial.println("START!");
      for (int i = 0; i < N_STEPPERS; i++) //setup the motors/home sensors
      {
        stepper[i].reset();
      }
      runTillStopped();
      isGameStarted = true;
      delay(150);
      
      // if (startGame())
      // {
      //   currentState = Playing; // Transition to the Playing state
      //   Serial.println("Button pressed. Transitioning to Playing state.");
      // } else {
      //   Serial.println("Button pressed, but game could not be started.");
      // }
    } else if (isGameStarted) {
      isGameStarted = false;
      for (int i = 0; i < N_STEPPERS; i++) //setup the motors/home sensors
      {
        stepper[i].stop();
      }
      runTillStopped();
      delay(150);
      pos = 0;
    }
  }
  lastButtonState = reading;

  // if(Serial1.available()){
  Serial.print("serial 1");
  Serial.println(Serial1.read());
  Serial.print("serial 2");
  Serial.println(Serial6.read());
  Serial.print("serial 3");
  Serial.println(Serial7.read());
  Serial.print("serial 4");
  Serial.println(Serial8.read());
  // }

  // // NOTE: no default case 'INITIALIZING' not handled
  // switch (currentState)
  // {
  //   case WaitingToStart:
  //     digitalWrite(DEBUG_LED[0], HIGH);
  //     digitalWrite(DEBUG_LED[1], LOW);
  //     digitalWrite(DEBUG_LED[2], LOW);
  //     digitalWrite(DEBUG_LED[3], LOW);
  //     // Check if the button is pressed to transition to the Playing state
  //     if (isGameStarted && buttonPressed)
  //     {
  //       buttonPressed = false; // Reset the flag
  //       currentState = Playing; // Transition to the Playing state
  //       Serial.println("Button pressed. Transitioning to Playing state.");
  //     }
  //   break;

  //   case Playing:
  //     // Check if any stepper has reached the maximum position
  //     isGameStarted = true; // Set isGameStarted to true when in the Playing state
  //     // NOTE: consistency: mixed index order? reordered
  //     digitalWrite(DEBUG_LED[0], LOW);
  //     digitalWrite(DEBUG_LED[1], HIGH);
  //     digitalWrite(DEBUG_LED[2], LOW);
  //     digitalWrite(DEBUG_LED[3], LOW);
  //     for (int i = 0; i < N_STEPPERS; i++)
  //     {
  //       if (abs(steppers[i].currentPosition()) >= MAX_POSITION) // NOTE: is MAX a hard stop?
  //       {
  //         endGame(i);
  //         currentState = GameOver;
  //         Serial.println("End of game, stepper reached maximum position");
  //         break;
  //       }
  //     }
  //   break;

  //   case GameOver:
  //     // NOTE: consistency: mixed index order? reordered
  //     digitalWrite(DEBUG_LED[0], LOW);
  //     digitalWrite(DEBUG_LED[1], LOW);
  //     digitalWrite(DEBUG_LED[2], LOW);
  //     digitalWrite(DEBUG_LED[3], HIGH);

  //     if (winningLaneBlinkTimer > winningLaneBlinkInterval)
  //     {
  //       // Toggle the winning lane LED every half second
  //       setLaneIndicator(winningLane, !getLaneIndicator(winningLane));
  //       Serial.println("Game over");
  //       // Reset the timer
  //       winningLaneBlinkTimer = 0;
  //     }
  //   break;

  //   case Resetting:
  //     // NOTE: consistency: mixed index order? reordered
  //     digitalWrite(DEBUG_LED[0], LOW);
  //     digitalWrite(DEBUG_LED[1], LOW);
  //     digitalWrite(DEBUG_LED[2], HIGH);
  //     digitalWrite(DEBUG_LED[3], LOW);

  //     homeAllSteppers();
  //     if (!anyStepperMoving())
  //     {
  //       isGameStarted = false;
  //       resettingGame = false;
  //       currentState = WaitingToStart;
  //     }
  //   break;

  //   default: // NOTE: added default case
  //     Serial.println("DEFAULT CASE: should only see INITIALIZING state");
  //   break;
  // }

  // Check if the homeButton is pressed to transition from WaitingToStart to Playing
  // if (currentState == WaitingToStart && buttonPressed && allSteppersHomed())
  // {
  //   currentState = Playing; // Transition to the Playing state
  //   buttonPressed = false; // Reset the buttonPressed flag
  //   Serial.println("Button pressed. Transitioning to Playing state.");
  // }

  if (isGameStarted)
  {
    // for (int i = 0; i < N_STEPPERS; i++)
    // {
    // }
    stepper[0].update();
    stepper[1].update();
    stepper[2].update();
    stepper[3].update();
  }

  // if (resettingGame && !anyStepperMoving())
  // {
  //   isGameStarted = false;
  //   resettingGame = false;
  // }

  // if (currentState == Resetting)
  // {
  //   for (int i = 0; i < N_STEPPERS; i++)
  //   {
  //     handleHoming(i); // Call the new handleHoming() function
  //   }
  // }

  // delay(10);
  if (cmils >= pmils + 500 && isGameStarted) {
    if (pos > 14000){
      isGameStarted = false;
    }
    
    if (i < 3){
      stepper[i].moveToPosition(pos);
      i++;
    } else {
      stepper[i].moveToPosition(pos);
      i = 0;
      pos = pos + 1000;
    }
    pmils = cmils;
  }
}
