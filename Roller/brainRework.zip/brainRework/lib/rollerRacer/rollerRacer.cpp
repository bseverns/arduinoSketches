// #include <rollerRacer.h>


// bool startGame()
// {
//   // Check if all steppers are homed
//   if (!allSteppersHomed())
//   {
//     Serial.println("Cannot start game. All steppers must be homed first.");
//     return false;
//   }

//   // Send 'H' command to sensor hubs to turn their light on
//   Serial1.write('H'); // Assuming lane 1 is connected to Serial1
//   Serial6.write('H'); // Assuming lane 2 is connected to Serial6
//   Serial7.write('H'); // Assuming lane 3 is connected to Serial6
//   Serial8.write('H'); // Assuming lane 4 is connected to Serial7

//   Serial.println("Game started");
//   playWav1.play("startGame.wav");
//   delay(2200);
//   playWav2.play("rollerGame.wav");
//   startChase(strip.Color(255, 0, 0)); // Red color chase

//   return true;
// }

// void startChase(uint32_t color)
// {
//   while (isGameStarted) {
//     for (int i = 0; i < LED_COUNT / 2; i++)
//     {
//       strip.setPixelColor(i, color);
//       strip.setPixelColor(LED_COUNT - 1 - i, color);
//       strip.show();
//       delay(100);
//       strip.setPixelColor(i, 0);
//       strip.setPixelColor(LED_COUNT - 1 - i, 0);
//       strip.show();
//     }
//   }
// }

// void setLaneIndicator(int laneId, bool isOk)
// {
//   if (laneId >= 0 && laneId < LANE_COUNT)
//   {
//     digitalWrite(DEBUG_LED[laneId], isOk ? HIGH : LOW);
//   }
// }

// void endGame(int laneId)
// {
//   strip.clear();

//   // Set the winning lane color
//   if (laneId >= 0 && laneId < N_STEPPERS)
//   {
//     winningLane = laneId;
//     strip.fill(laneColors[winningLane], 0, LED_COUNT);
//   }

//   strip.show();
//   Serial.println("Game ended");
//   homeAllSteppers();
//   resettingGame = true; // Set flag to start the resetting process

//   // Send code to the corresponding sensor hub to toggle the light every half second
//   switch (laneId)
//   {
//     case 0:
//       Serial1.write('T'); // Assuming lane 1 is connected to Serial1
//       Serial6.write('O'); // Turn off lane 2 light
//       Serial7.write('O'); // Turn off lane 3 light
//       Serial8.write('O'); // Turn off lane 4 light
//     break;

//     case 1:
//       Serial1.write('O'); // Turn off lane 1 light
//       Serial6.write('T'); // Assuming lane 2 is connected to Serial6
//       Serial7.write('O'); // Turn off lane 3 light
//       Serial8.write('O'); // Turn off lane 4 light
//     break;

//     case 2:
//       Serial1.write('O'); // Turn off lane 1 light
//       Serial6.write('O'); // Turn off lane 2 light
//       Serial7.write('T'); // Assuming lane 3 is connected to Serial6 // NOTE: Serial7
//       Serial8.write('O'); // Turn off lane 4 light
//     break;

//     case 3:
//       Serial1.write('O'); // Turn off lane 1 light
//       Serial6.write('O'); // Turn off lane 2 light
//       Serial7.write('O'); // Turn off lane 3 light
//       Serial8.write('T'); // Assuming lane 4 is connected to Serial7 // NOTE: Serial8
//     break;

//     default:
//     break;
//   }

//   delay(500); // Delay for 0.5 seconds before toggling the light
//   setLaneIndicator(laneId, !getLaneIndicator(laneId)); // Toggle the light on the winning lane
//   // Reset the timer
//   winningLaneBlinkTimer = 0;
// }