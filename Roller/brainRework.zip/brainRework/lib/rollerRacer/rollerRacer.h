// # ifndef ROLLER_RACER_H
// # define ROLLER_RACER_H

// #include <gameDefs.h>
// #include <audioDefs.h>
// #include <stepperFuncs.h>

// extern bool startGame();

// extern void startChase(uint32_t color);

// void setLaneIndicator(int laneId, bool isOk);

// void endGame(int laneId);

// # endif // ROLLER_RACER_H