#include <stepperFuncs.h>

extern StepperMotor stepper[N_STEPPERS] = {
  StepperMotor(MOTOR_INTERFACE_TYPE, STEP_PIN[0], DIR_PIN[0], HOME_SENSOR[0]),
  StepperMotor(MOTOR_INTERFACE_TYPE, STEP_PIN[1], DIR_PIN[1], HOME_SENSOR[1]),
  StepperMotor(MOTOR_INTERFACE_TYPE, STEP_PIN[2], DIR_PIN[2], HOME_SENSOR[2]),
  StepperMotor(MOTOR_INTERFACE_TYPE, STEP_PIN[3], DIR_PIN[3], HOME_SENSOR[3])

};

// AccelStepper steppers[N_STEPPERS] = {
//   AccelStepper(1, STEP_PIN[0], DIR_PIN[0]),
//   AccelStepper(1, STEP_PIN[1], DIR_PIN[1]),
//   AccelStepper(1, STEP_PIN[2], DIR_PIN[2]),
//   AccelStepper(1, STEP_PIN[3], DIR_PIN[3])
// };

const uint32_t laneColors[] = {
  strip.Color(0, 210, 255), // Teal - lane 1
  strip.Color(255, 210, 0), // Orange-Yellow - lane 2
  strip.Color(210, 0, 255), // Purple - lane 3
  strip.Color(170, 210, 0) // Green - lane 4
};

// bool allSteppersHomed()
// {
//   for (int i = 0; i < N_STEPPERS; i++)
//   {
//     if (!isHomed[i])
//     {
//       return false;
//     }
//   }
//   return true;
// }

// bool getLaneIndicator(int laneId)
// {
//   if (laneId >= 0 && laneId < LANE_COUNT)
//   {
//     return digitalRead(DEBUG_LED[laneId]) == HIGH;
//   }
//   return false;
// }

// bool isStepperMoving(int i)
// {
//   if (i >= 0 && i < N_STEPPERS)
//   {
//     return steppers[i].isRunning();
//   }
//   return false;
// }

// bool anyStepperMoving()
// {
//   for (int i = 0; i < N_STEPPERS; i++)
//   {
//     if (steppers[i].isRunning())
//     {
//       return true;
//     }
//   }
//   return false;
// }

// // Function to handle the home sensor interrupt
// void handleHomeSensorInterrupt(int i)
// {
//   // Read the current state of the home sensor
//   bool currentState = digitalRead(HOME_SENSOR(i));

//   // If the state has changed from the previous state
//   if (currentState != homeSensorState[i])
//   {
//     homeSensorState[i] = currentState;

//     // If the home sensor is triggered (LOW state)
//     if (currentState == LOW)
//     {
//       steppers[i].stop();
//       steppers[i].setSpeed(0);
//       steppers[i].setCurrentPosition(0);
//       reverseDirection[i] = true;
//       isHomed[i] = true;
//       Serial.println("Stepper " + String(i) + " reached home position");
//     }
//   }
// }

// void handleHoming(int i)
// {
//   if (!isHomed[i])
//   {
//     if (digitalRead(HOME_SENSOR(i)) == LOW)
//     {
//       steppers[i].stop();
//       steppers[i].setSpeed(0);
//       steppers[i].setCurrentPosition(0);
//       reverseDirection[i] = true;
//       isHomed[i] = true;
//       Serial.println("Stepper " + String(i) + " reached home position");
//     } else {
//       // NOTE: stepperfintln -> typo
//       // stepperfintln("Stepper " + String(i) + " is homing...");
//       Serial.println("Stepper " + String(i) + " is homing...");
//     }
//   } else {
//     if (digitalRead(HOME_SENSOR(i)) == LOW && !reverseDirection[i])
//     {
//       steppers[i].move(MAX_POSITION);
//       reverseDirection[i] = true;
//       Serial.println("Stepper " + String(i) + " is moving towards the maximum position...");
//     } else if (digitalRead(HOME_SENSOR(i)) == HIGH && reverseDirection[i]) {
//       steppers[i].stop();
//       steppers[i].setCurrentPosition(MAX_POSITION);
//       reverseDirection[i] = false;
//       isHomed[i] = false;
//       Serial.println("Stepper " + String(i) + " returned to the starting position");
//     } else {
//       steppers[i].setSpeed(100);
//       steppers[i].setAcceleration(500);
//       steppers[i].runSpeed();
//       Serial.println("Stepper " + String(i) + " is moving...");
//     }
//   }
// }

// // Function to handle the home sensor interrupt
// void handleHomeSensorInterrupt0()
// {
//   handleHomeSensorInterrupt(0);
// }

// void handleHomeSensorInterrupt1()
// {
//   handleHomeSensorInterrupt(1);
// }

// void handleHomeSensorInterrupt2()
// {
//   handleHomeSensorInterrupt(2);
// }

// void handleHomeSensorInterrupt3()
// {
//   handleHomeSensorInterrupt(3);
// }

// void homeAllSteppers()
// {
//   Serial.println("Going home!");
//   for (int i = 0; i < N_STEPPERS; i++)
//   {
//     isHomed[i] = false;
//     reverseDirection[i] = false;
//     steppers[i].move(-MAX_POSITION); // start all motors moving towards home
//   }
// }

// // This is the ISR that gets called when the button is pressed
// // NOTE: ISR carried over from PIC?
// void buttonPress()
// {
//   buttonPressed = true;
// }
