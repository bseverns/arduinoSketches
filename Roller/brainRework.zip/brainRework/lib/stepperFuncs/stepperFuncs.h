// #ifndef STEPPER_FUNCS_H
// #define STEPPER_FUNCS_H

#include <gameDefs.h>
#include <StepperMotor.h>

extern StepperMotor stepper[];
extern const uint32_t laneColors[];
// extern AccelStepper steppers[N_STEPPERS];

// bool allSteppersHomed();

// bool getLaneIndicator(int laneId);

// bool isStepperMoving(int i);

// bool anyStepperMoving();

// void handleHomeSensorInterrupt(int i);

// void handleHoming(int i);

// void handleHomeSensorInterrupt0();
// void handleHomeSensorInterrupt1();
// void handleHomeSensorInterrupt2();
// void handleHomeSensorInterrupt3();

// void homeAllSteppers();

// void buttonPress();

// #endif // STEPPER_FUNCS_H