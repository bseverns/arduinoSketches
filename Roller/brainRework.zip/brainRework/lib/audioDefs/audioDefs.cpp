#include "audioDefs.h"

// Audio library objects
AudioPlaySdWav playWav1; // for the startGame sound
AudioPlaySdWav playWav2; // for the rollerGame sound
AudioPlaySdWav playWav3; // for the ballHit sound
AudioOutputI2SOct audioOutput;
AudioMixer4 mixer1; // Add a mixer
AudioMixer4 mixer2; // Add a second mixer
AudioMixer4 mixer3; // Add a third mixer

AudioConnection patchCord1(playWav1, 0, mixer1, 0); // Connect playWav1 to the first mixer
AudioConnection patchCord2(playWav1, 1, mixer1, 1); // Connect playWav1 to the first mixer
AudioConnection patchCord3(playWav2, 0, mixer2, 0); // Connect playWav2 to the second mixer
AudioConnection patchCord4(playWav2, 1, mixer2, 1); // Connect playWav2 to the second mixer
AudioConnection patchCord5(playWav3, 0, mixer3, 0); // Connect playWav3 to the third mixer
AudioConnection patchCord6(playWav3, 1, mixer3, 1); // Connect playWav3 to the third mixer
AudioConnection patchCord7(mixer1, audioOutput); // Connect the first mixer to the output
AudioConnection patchCord8(mixer2, audioOutput); // Connect the second mixer to the output
AudioConnection patchCord9(mixer3, audioOutput); // Connect the third mixer to the output
