# ifndef AUDIO_DEFS_H
# define AUDIO_DEFS_H

#include <Audio.h>

// Audio library objects
extern AudioPlaySdWav playWav1; // for the startGame sound
extern AudioPlaySdWav playWav2; // for the rollerGame sound
extern AudioPlaySdWav playWav3; // for the ballHit sound
extern AudioOutputI2SOct audioOutput;
extern AudioMixer4 mixer1; // Add a mixer
extern AudioMixer4 mixer2; // Add a second mixer
extern AudioMixer4 mixer3; // Add a third mixer

# endif // AUDIO_DEFS_H