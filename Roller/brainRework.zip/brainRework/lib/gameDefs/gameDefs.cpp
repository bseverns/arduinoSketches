#include <gameDefs.h>

int HOME_SENSOR[N_STEPPERS]={ 30, 32, 36, 38 };
int STEP_PIN[N_STEPPERS]={ 18, 14, 16, 12 };
int DIR_PIN[N_STEPPERS]={ 17, 13, 15, 11 };

State currentState = Initialising;

const int startButton = 2;
bool isHomed[N_STEPPERS] = { false };
bool reverseDirection[N_STEPPERS] = { false };
bool isGameStarted = false;
bool resettingGame = false;
bool sendingData = false; // NOTE: unused var
bool laneState = false; // NOTE: unused var
uint8_t winningLane = 0;
volatile bool buttonPressed = false; // This variable will be changed in the ISR
// Variables to hold the previous state of the home sensors
volatile bool homeSensorState[N_STEPPERS] = { false };
bool buttonState = HIGH; // current state of the button
bool lastButtonState = HIGH; // previous state of the button
unsigned long buttonPressTime = 0; // time of the last button press
unsigned long debounceDelay = 50; // debounce delay in milliseconds

const int DEBUG_LED[LANE_COUNT] = { 3, 4, 5, 6 };
elapsedMillis winningLaneBlinkTimer;
const unsigned long winningLaneBlinkInterval = 500;

Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800); //neopixel strips: 21-21
