# ifndef GAME_DEFS_H
# define GAME_DEFS_H

#include <Arduino.h>
#include <AccelStepper.h>
#include <Adafruit_NeoPixel.h>

//constants
#define LED_PIN 23
#define LED_COUNT 42
#define N_STEPPERS 4


// Steppers
#define MOTOR_INTERFACE_TYPE 1
extern int HOME_SENSOR[N_STEPPERS];
extern int STEP_PIN[N_STEPPERS];
extern int DIR_PIN[N_STEPPERS];

#define MAX_POSITION 14000
#define BACKOFF_STEPS 150
#define LANE_COUNT 4

enum State {
  Initialising,
  WaitingToStart,
  Playing,
  GameOver,
  Resetting
};

enum LaneColor {
  LANE_TEAL,
  LANE_ORANGE_YELLOW,
  LANE_PURPLE,
  LANE_GREEN
};

extern State currentState;

extern const int startButton;
extern bool isHomed[N_STEPPERS];
extern bool reverseDirection[N_STEPPERS];
extern bool isGameStarted;
extern bool resettingGame;
extern bool sendingData; // NOTE: unused var
extern bool laneState; // NOTE: unused var
extern uint8_t winningLane;
extern volatile bool buttonPressed; // This variable will be changed in the ISR
// Variables to hold the previous state of the home sensors
extern volatile bool homeSensorState[N_STEPPERS];
extern bool buttonState; // current state of the button
extern bool lastButtonState; // previous state of the button
extern unsigned long buttonPressTime; // time of the last button press
extern unsigned long debounceDelay; // debounce delay in milliseconds

extern const int DEBUG_LED[LANE_COUNT];
extern elapsedMillis winningLaneBlinkTimer;
extern const unsigned long winningLaneBlinkInterval;

extern Adafruit_NeoPixel strip; //neopixel strips: 21-21

# endif // GAME_DEFS_H