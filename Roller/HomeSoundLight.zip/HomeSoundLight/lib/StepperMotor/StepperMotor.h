#ifndef STEPPERMOTOR_H
#define STEPPERMOTOR_H

#include <AccelStepper.h>

enum MotorState {
  INIT,
  MOVING_TO_HOME,
  MOVING_TO_SOFTHOME,
  BACKING_OFF_SWITCH,
  AT_SOFT_HOME,
  AT_END,
  MOVING_TO_POSITION,
  STOPPED
};

class StepperMotor {
private:
  AccelStepper stepper;  // Create an AccelStepper object
  int homeSwitchPin;
  MotorState state;
  bool homingInProgress;
  bool previousSwitchState;
  long cpos = 0;

public:
  StepperMotor(int step, int dir, int homeSwitch)
    : stepper(AccelStepper::DRIVER, step, dir),
      homeSwitchPin(homeSwitch),
      state(INIT),
      previousSwitchState(true),
      cpos(0) {
    pinMode(homeSwitchPin, INPUT_PULLUP);
    stepper.setMaxSpeed(2500);
    stepper.setAcceleration(5000);
    bool homingInProgress = false;
   // stepper.setDirection(AccelStepper::DIRECTION_BACKWARD); // Set the direction to BACKWARD
  }

void moveToHome();
    void reset();
    void moveToPosition(long position);
    void stop();
    void update();
    void move(int steps);
    MotorState getState();
    void setSpeed(int speed);
    void setHomingInProgress(bool inProgress);
};

#endif // STEPPERMOTOR_H