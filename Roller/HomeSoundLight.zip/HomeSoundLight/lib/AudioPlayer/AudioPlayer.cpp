#include "AudioPlayer.h"

AudioPlayer::AudioPlayer() :
  patchCord1(playSdWav, 0, i2s, 0), patchCord2(playSdWav, 1, i2s, 1) {}

void AudioPlayer::begin(float volume) {
  AudioMemory(8);
  sgtl5000.enable();
  sgtl5000.volume(volume);
}

bool AudioPlayer::play(const char *filename) {
  if (playSdWav.isPlaying()) return false;
  return playSdWav.play(filename);
}

void AudioPlayer::stop() {
  if (playSdWav.isPlaying()) {
    playSdWav.stop();
  }
}

bool AudioPlayer::isPlaying() {
  return playSdWav.isPlaying();
}

void AudioPlayer::pause() {
  if (playSdWav.isPlaying()) {
    playSdWav.pause();
  }
}

void AudioPlayer::resume() {
  if (playSdWav.isPaused()) {
    playSdWav.resume();
  }
}