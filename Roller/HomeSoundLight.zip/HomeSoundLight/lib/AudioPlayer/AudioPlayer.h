#ifndef AUDIOPLAYER_H
#define AUDIOPLAYER_H

#include <Audio.h>
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <SerialFlash.h>

class AudioPlayer {
private:
  AudioPlaySdWav playSdWav;
  AudioOutputI2S i2s;
  AudioConnection patchCord1;
  AudioConnection patchCord2;
  AudioControlSGTL5000 sgtl5000;

public:
  AudioPlayer();
  void begin(float volume);
  bool play(const char *filename);
  void stop();
  bool isPlaying();
  void pause();
  void resume();
};

#endif // AUDIOPLAYER_H